
package actividade.de.limpieza;

import Vista.LoginView;

public class ActividadeDeLimpieza {

    public static void main(String[] args) {
        // Lanzar la ventana de login como punto de inicio
        LoginView.main(args);
    }
}
