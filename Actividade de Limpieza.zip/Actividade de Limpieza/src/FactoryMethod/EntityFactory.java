
package FactoryMethod;
public abstract class EntityFactory {
    public abstract Object crearEntidad(String tipo);
}

